//
//  main.cpp
//  project2
//
//  Created by Michał Sondej on 27/04/2023.
//

#include <iostream>
using namespace std;

const int citiesArraySize = 10;

class myString
{
private:
    char* str;
    int length;

public:
    myString()
    {
        str = new char[1];
        str[0] = '\0';
        length = 0;
    }
    myString(char* value)
    {
        length = 0;
        if (value == nullptr)
        {
            str = new char[1];
            str[0] = '\0';
        }
        else
        {
            length = 0;
            while (value[length] != '\0')
            {
                length++;
            }
            str = new char[length + 1];
            str[length] = '\0';
            for (int i = 0; i < length; i++)
            {
                str[i] = value[i];
            }
        }
    }
    void putToString(char* value)
    {
        delete[] str;
        length = 0;
        if (value == nullptr)
        {
            str = new char[1];
            str[0] = '\0';
        }
        else
        {
            length = 0;
            while (value[length] != '\0')
            {
                length++;
            }
            str = new char[length + 1];
            str[length] = '\0';
            for (int i = 0; i < length; i++)
            {
                str[i] = value[i];
            }
        }
    }
    void clearString()
    {
        delete[] str;
        str = new char[1];
        str[0] = '\0';
        length = 0;
    }
    bool isNumber()
    {
        bool isThisANuber = 0;
        char digits[10] = { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };
        for (int i = 0; i < length; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                if (str[i] == digits[j])
                {
                    isThisANuber = true;
                    break;
                }
            }
            if (isThisANuber == false)
            {
                return false;
            }
            isThisANuber = false;
        }
        return true;
    }
    bool isCommandLetter()
    {
        if (str[0] != 'S' && str[0] != 'A')
        {
            return false;
        }
        char letters[10] = { 'S', 'A' };
        for (int i = 0; i < length - 1; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                if (str[i] != letters[j])
                {
                    return false;
                }
            }
        }
        return true;
    }
    int toNumber()
    {
        int result = 0;
        int finalResult = 0;
        if (this->isNumber())
        {
            for (int i = 0; i < length; i++)
            {
                result += (int(str[i]) - 48);
                for (int j = 0; j < length - i - 1; j++)
                {
                    result *= 10;
                }
                finalResult += result;
                result = 0;
            }
        }
        return finalResult;
    }
    bool compareToALetter(char a)
    {
        if (length == 1 && str[0] == a)
        {
            return true;
        }
        return false;
    }
    bool compareToAnotherString(myString a)
    {
        if (length != a.length)
        {
            return false;
        }
        for (int i = 0; i < length; i++)
        {
            if (str[i] != a.str[i])
            {
                return false;
            }
        }
        return true;
    }
    void printMyString()
    {
        for (int i = 0; i < length; i++)
        {
            cout << str[i];
        }
    }
    myString& operator+=(const char letter)
    {
        if (length != 0 && str[0] != '\0')
        {
            char* updatedString;
            length += 1;
            updatedString = new char[length + 1];
            for (int i = 0; i < length - 1; i++)
            {
                updatedString[i] = str[i];
            }
            updatedString[length - 1] = letter;
            updatedString[length] = '\0';
            char* tmp;
            tmp = str;
            str = updatedString;
            updatedString = tmp;
            delete[] tmp;
            return *this;
        }
        else
        {
            length += 1;
            str[0] = letter;
            return *this;
        }

    }
    myString& operator=(const myString& other)
    {
        if (this != &other)
        {
            str = new char[1];
            delete[] str;
            length = other.length;
            str = new char[length + 1];
            for (int i = 0; i < length; ++i)
            {
                str[i] = other.str[i];
            }
            str[length] = '\0';
        }
        return *this;
    }
    //~myString()
    //{
    //    delete[] str;
    //}

};


struct flightConnection
{
    myString source;
    myString destination;
    int flightTime;
};
struct city
{
    myString name;
    int x;
    int y;
    int adjaciencyMatrixPlacement;
};
struct myVectorNode
{
    myString city;
    myVectorNode* next;
    myVectorNode* prev;
};

struct position
{
    int x;
    int y;
    int distance;
};


class myVector
{
private:
    myVectorNode* head;
    myVectorNode* tail;
public:
    myVector()
    {
        head = nullptr;
        tail = nullptr;
    }
    void pushBack(myString city)
    {
        myVectorNode* newNode = new myVectorNode;
        newNode->city = city;
        newNode->next = nullptr;
        newNode->prev = tail;
        
        if (head == nullptr) {
            head = newNode;
            tail = newNode;
        }
        else {
            tail->next = newNode;
            tail = newNode;
        }
    }
    
    void print()
    {
        myVectorNode* current = tail;
        while (current != head) {
            current->city.printMyString();
            cout<<" ";
            current = current->prev;
        }
    }
};

struct query
{
    myString source;
    myString destination;
    bool type;
    myVector path;
    int time;
};

struct myQueueNode
{
    int x;
    int y;
    myQueueNode* next;
};

class myQueue
{
private:
    myQueueNode* head;
    myQueueNode* tail;
public:
    myQueue()
    {
        head = nullptr;
        tail = nullptr;
    }
    void push(int x, int y)
    {
        myQueueNode* newNode = new myQueueNode;
        newNode->x = x;
        newNode->y = y;
        newNode->next = nullptr;

        // If the queue is empty, the new node becomes the head and tail
        if (head == nullptr) {
            head = newNode;
            tail = newNode;
        }
        else {
            // Otherwise, add the new node to the end of the queue
            tail->next = newNode;
            tail = newNode;
        }
    }
    myQueueNode* pop()
    {
        // If the queue is empty, there is nothing to pop
        if (head == nullptr) {
            return nullptr;
        }

        // Remove the head node from the queue
        myQueueNode* nodeToRemove = head;
        head = head->next;

        // If the head becomes nullptr, the queue is now empty and the tail should also be nullptr
        if (head == nullptr) {
            tail = nullptr;
        }

        // Free the memory used by the removed node
        return nodeToRemove;
    }
    bool is_empty()
    {
        return head == nullptr;
    }
};

bool is_valid(int x, int y, bool** isPassableMap, bool** visited, int w, int h) {
    // Check if the point is within the grid and can be visited
    return x >= 0 && x < w && y >= 0 && y < h && isPassableMap[x][y] == 1 && !visited[x][y];
}

void bfs(int start_x, int start_y, int endX, int endY, bool** visited, bool** isPassableMap, int w, int h, int** distances, position** parents)
{
    myQueue q;
    q.push(start_x, start_y);
    distances[start_x][start_y] = 0;
    position parentPosition;

    visited[start_x][start_y] = true;

    while (!q.is_empty())
    {
        myQueueNode* node = q.pop();
        if(node->x==endX && node->y==endY)
        {
            return;
        }
        int dx[]={-1, 0, 1, 0};
        int dy[]={0, -1, 0, 1};
        for (int i = 0; i < 4; i++) {
            int neighbor_x = node->x + dx[i];
            int neighbor_y = node->y + dy[i];

            if (is_valid(neighbor_x, neighbor_y, isPassableMap, visited, w, h))
            {
                distances[neighbor_x][neighbor_y] = distances[node->x][node->y]+1;
                if(distances[neighbor_x][neighbor_y]<parents[neighbor_x][neighbor_y].distance)
                {
                    parentPosition.x = node->x;
                    parentPosition.y = node->y;
                    parentPosition.distance = distances[neighbor_x][neighbor_y];
                    parents[neighbor_x][neighbor_y] = parentPosition;
                }
                q.push(neighbor_x, neighbor_y);
                visited[neighbor_x][neighbor_y] = true;
            }
        }
    }
}

//void dfs(int x, int y, int x2, int y2, int cur_dist, bool** isPassableMap, bool** visited, int w, int h, int** distance)
//{
//    if(cur_dist<distance[x][y] || distance[x][y]==0)
//    {
//        distance[x][y] = cur_dist;
//    }
//
//    if (x == x2 && y == y2) {
//        // If we reach the target point, we have found the shortest path
//        return;
//    }
//    visited[x][y] = true;
//
//    // Check all possible adjacent points and recursively call dfs
//    if(is_valid(x-1, y, isPassableMap, visited, w, h))
//    {
//        dfs(x-1, y, x2, y2, cur_dist+1, isPassableMap, visited, w, h, distance);
//    }
//    if(is_valid(x+1, y, isPassableMap, visited, w, h))
//    {
//        dfs(x+1, y, x2, y2, cur_dist+1, isPassableMap, visited, w, h, distance);
//    }
//    if(is_valid(x, y-1, isPassableMap, visited, w, h))
//    {
//        dfs(x, y-1, x2, y2, cur_dist+1, isPassableMap, visited, w, h, distance);
//    }
//    if(is_valid(x, y+1, isPassableMap, visited, w, h))
//    {
//        dfs(x, y+1, x2, y2, cur_dist+1, isPassableMap, visited, w, h, distance);
//    }
//    return;
//}
int find_shortest_path(int x1, int y1, int x2, int y2, int h, int w, bool** visited, int** distance, bool** isPassableMap, position** parents)
{
    for(int i=0; i<h; i++)
    {
        for(int j=0; j<w; j++)
        {
            visited[i][j]=0;
            distance[i][j]=0;
            parents[i][j].distance = 999999999;
        }
    }

    bfs(x1, y1, x2, y2,  visited, isPassableMap, w, h, distance, parents);
//    for(int i=0; i<h; i++)
//    {
//        for(int j=0; j<w; j++)
//        {
//            cout<<parents[i][j].x<<","<<parents[i][j].y<<" ";
//        }
//        cout<<endl;
//    }
    return distance[x2][y2];
}

int readMap(int w, int h, char** map, bool** isPassableMap, city* cities, int& n)
{
    int numberOfCities=0;
    myString cityName;
    bool isCityNameFinished = 0;
    char previousChar = ' ';
    char currentChar = ' ';
    bool isFirstLetter = 0;
    bool isPreviousLastLetter = 0;
    bool isThisLastLetter = 0;
    for(int i=0; i<h; i++)
    {
        for(int j=0; j<w; j++)
        {
            cin>>map[i][j];
        }
    }
    for(int i=0; i<h; i++)
    {
        for(int j=0; j<w; j++)
        {
            isFirstLetter = 0;
            isPreviousLastLetter = 0;
            isThisLastLetter = 0;
            previousChar = currentChar;
            currentChar = map[i][j];
            if(((int(previousChar)>='0' && int(previousChar)<='9') || (int(previousChar)>='A' && int(previousChar)<='Z'))==false && ((int(currentChar)>='0' && int(currentChar)<='9') || (int(currentChar)>='A' && int(currentChar)<='Z'))==true)
            {
                isFirstLetter = 1;
            }
            if(((int(previousChar)>='0' && int(previousChar)<='9') || (int(previousChar)>='A' && int(previousChar)<='Z'))==true && ((int(currentChar)>='0' && int(currentChar)<='9') || (int(currentChar)>='A' && int(currentChar)<='Z'))==false)
            {
                isPreviousLastLetter = 1;
            }
            if(((int(currentChar)>='0' && int(currentChar)<='9') || (int(currentChar)>='A' && int(currentChar)<='Z')) && j == w-1)
            {
                isThisLastLetter = 1;
            }
            if(numberOfCities == n)
            {
                city* newCities = new city[n * 2];
                for (int i = 0; i < n; i++)
                {
                    newCities[i] = cities[i];
                }
                delete[] cities;
                cities = newCities;
                n *= 2;
            }
            if((int(currentChar)>='0' && int(currentChar)<='9') || (int(currentChar)>='A' && int(currentChar)<='Z'))
            {
                cityName+=map[i][j];
            }
            if(isFirstLetter)
            {
                if(i-1>=0 && j-1>=0 && map[i-1][j-1]=='*')
                {
                    cities[numberOfCities].x = i-1;
                    cities[numberOfCities].y = j-1;
                }
                if(i-1>=0 && map[i-1][j]=='*')
                {
                    cities[numberOfCities].x = i-1;
                    cities[numberOfCities].y = j;
                }
                if(i-1>=0 && j+1<w && map[i-1][j+1]=='*')
                {
                    cities[numberOfCities].x = i-1;
                    cities[numberOfCities].y = j+1;
                }
                if(j-1>=0 && map[i][j-1]=='*')
                {
                    cities[numberOfCities].x = i;
                    cities[numberOfCities].y = j-1;
                }
                if(j+1<w && map[i][j+1]=='*')
                {
                    cities[numberOfCities].x = i;
                    cities[numberOfCities].y = j+1;
                }
                if(i+1<h && j-1>=0 && map[i+1][j-1]=='*')
                {
                    cities[numberOfCities].x = i+1;
                    cities[numberOfCities].y = j-1;
                }
                if(i+1<h && map[i+1][j]=='*')
                {
                    cities[numberOfCities].x = i+1;
                    cities[numberOfCities].y = j;
                }
                if(i+1<h && j+1<w &&map[i+1][j+1]=='*')
                {
                    cities[numberOfCities].x = i+1;
                    cities[numberOfCities].y = j+1;
                }
            }
            else if(isThisLastLetter)
            {
                if(i-1>=0 && map[i-1][j-1]=='*')
                {
                    cities[numberOfCities].x = i-1;
                    cities[numberOfCities].y = j-1;
                }
                if(i-1>=0 && map[i-1][j]=='*')
                {
                    cities[numberOfCities].x = i-1;
                    cities[numberOfCities].y = j;
                }
                if(map[i][j-1]=='*')
                {
                    cities[numberOfCities].x = i;
                    cities[numberOfCities].y = j-1;
                }
                if(i+1<h && map[i+1][j-1]=='*')
                {
                    cities[numberOfCities].x = i+1;
                    cities[numberOfCities].y = j-1;
                }
                if(i+1<h && map[i+1][j]=='*')
                {
                    cities[numberOfCities].x = i+1;
                    cities[numberOfCities].y = j;
                }
                isCityNameFinished = 1;
                
            }
            else if(isPreviousLastLetter)
            {
                if(i-1>=0 && j-2>=0 && map[i-1][j-2]=='*')
                {
                    cities[numberOfCities].x = i-1;
                    cities[numberOfCities].y = j-2;
                }
                if(i-1>=0 && j-1>=0 && map[i-1][j-1]=='*')
                {
                    cities[numberOfCities].x = i-1;
                    cities[numberOfCities].y = j-1;
                }
                if(i-1>=0 && map[i-1][j]=='*')
                {
                    cities[numberOfCities].x = i-1;
                    cities[numberOfCities].y = j;
                }
                if(j-2>=0 && map[i][j-2]=='*')
                {
                    cities[numberOfCities].x = i;
                    cities[numberOfCities].y = j-2;
                }
                if(map[i][j]=='*')
                {
                    cities[numberOfCities].x = i;
                    cities[numberOfCities].y = j;
                }
                if(i+1<h && j-2>=0 && map[i+1][j-2]=='*')
                {
                    cities[numberOfCities].x = i+1;
                    cities[numberOfCities].y = j-2;
                }
                if(i+1<h && j-1==0 && map[i+1][j-1]=='*')
                {
                    cities[numberOfCities].x = i+1;
                    cities[numberOfCities].y = j-1;
                }
                if(i+1<h && map[i+1][j]=='*')
                {
                    cities[numberOfCities].x = i+1;
                    cities[numberOfCities].y = j;
                }
                isCityNameFinished = 1;
            }
            if(isThisLastLetter && isFirstLetter)
            {
                isCityNameFinished=1;
            }
            if(isCityNameFinished == 1)
            {
                cities[numberOfCities].name = cityName;
                cityName.clearString();
                isCityNameFinished=0;
                numberOfCities++;
            }
            if(map[i][j]=='#' ||  map[i][j]=='*')
            {
                isPassableMap[i][j]=1;
            }
            else
            {
                isPassableMap[i][j]=0;
            }
        }
    }
    return numberOfCities;
}
void createPathVector(position** parents, int x2, int y2, int x1, int y1, myVector** travelPath, char** map, int numberOfCities, city* cities, int xBegin, int yBegin)
{
    if(x2==x1 && y2==y1)
    {
        return;
    }
    else
    {
        if(map[x2][y2]=='*')
        {
            for(int i=0; i<numberOfCities; i++)
            {
                if(cities[i].x==x2 && cities[i].y==y2)
                {
                    for(int j=0; j<numberOfCities; j++)
                    {
                        if(cities[j].x==xBegin && cities[j].y==yBegin)
                        {
                            for(int k=0; k<numberOfCities; k++)
                            {
                                if(cities[k].x==x1 && cities[k].y==y1)
                                {
                                    travelPath[j][k].pushBack(cities[i].name);
                                    break;
                                }
                            }
                            break;
                        }
                    }
                    break;
                }
            }
        }
        createPathVector(parents, parents[x2][y2].x, parents[x2][y2].y, x1, y1, travelPath, map, numberOfCities, cities, xBegin, yBegin);
    }
}
int main(int argc, const char * argv[])
{
    int w, h;
    int n = citiesArraySize;
    cin>>w>>h;
    char** map = new char*[h];
    bool** isPassableMap = new bool*[h];
    bool** visited = new bool*[h];
    int** distance = new int*[h];
    position** parents = new position*[h];
    city* cities = new city[n];
    
    for (int i = 0; i < h; i++)
    {
        map[i] = new char[w];
        isPassableMap[i] = new bool[w];
        visited[i] = new bool[w];
        distance[i] = new int[w];
        parents[i] = new position[w];
    }
    int numberOfCities=0;
    numberOfCities = readMap(w, h, map, isPassableMap, cities, n);
    int** adjaciencyMatrixCities = new int*[numberOfCities];
    myVector** travelPath = new myVector*[numberOfCities];
    for(int i=0; i<numberOfCities; i++)
    {
        adjaciencyMatrixCities[i] = new int[numberOfCities];
        travelPath[i] = new myVector[numberOfCities];
    }
    for(int i=0; i<numberOfCities; i++)
    {
        for(int j=0; j<numberOfCities; j++)
        {
            adjaciencyMatrixCities[i][j] = find_shortest_path(cities[i].x, cities[i].y, cities[j].x, cities[j].y, h, w, visited, distance, isPassableMap, parents);
            createPathVector(parents, cities[j].x, cities[j].y, cities[i].x, cities[i].y, travelPath, map, numberOfCities, cities, cities[j].x, cities[j].y);
        }
    }
//    for(int i=0; i<h; i++)
//    {
//        for(int j=0; j<h; j++)
//        {
//            cout<<isPassableMap[i][j];
//        }
//        cout<<endl;
//    }
//    for(int i=0; i<numberOfCities; i++)
//    {
//        for(int j=0; j<numberOfCities; j++)
//        {
//            cout<<adjaciencyMatrixCities[i][j]<<" ";
//        }
//        cout<<endl;
//    }
    int k;
    cin>>k;
    flightConnection* flights = new flightConnection[k];
    for(int i=0; i<k; i++)
    {
        char tmp[100];
        cin>>tmp;
        flights[i].source.putToString(tmp);
        cin>>tmp;
        flights[i].destination.putToString(tmp);
        cin>>flights[i].flightTime;
    }
    for(int i=0; i<k; i++)
    {
        for(int j=0; j<numberOfCities; j++)
        {
            for(int k=0; k<numberOfCities; k++)
            {
                if(cities[j].name.compareToAnotherString(flights[i].source) && cities[k].name.compareToAnotherString(flights[i].destination))
                {
                    if(adjaciencyMatrixCities[j][k]>flights[i].flightTime)
                    adjaciencyMatrixCities[j][k] = flights[i].flightTime;
                }
            }
        }
    }
    int q;
    cin>>q;
    query* travels = new query[q];
    for(int i=0; i<q; i++)
    {
        char tmp[100];
        cin>>tmp;
        travels[i].source.putToString(tmp);
        cin>>tmp;
        travels[i].destination.putToString(tmp);
        cin>>travels[i].type;
    }
    for(int i=0; i<q; i++)
    {
        for(int j=0; j<numberOfCities; j++)
        {
            for(int k=0; k<numberOfCities; k++)
            {
                if(cities[j].name.compareToAnotherString(travels[i].source) && cities[k].name.compareToAnotherString(travels[i].destination))
                {
                    if(travels[i].type == 0)
                    {
                        cout<<adjaciencyMatrixCities[j][k]<<endl;
                    }
                    else
                    {
                        cout<<adjaciencyMatrixCities[j][k]<<" ";
                        if(adjaciencyMatrixCities[j][k]==adjaciencyMatrixCities[k][j])
                        {
                            travelPath[k][j].print();
                        }
                        cout<<endl;
                    }
                }
            }
        }
    }
//    for(int j=0; j<numberOfCities; j++)
//    {
//        for(int k=0; k<numberOfCities; k++)
//        {
//            cout<<adjaciencyMatrixCities[j][k]<<" ";
//        }
//        cout<<endl;
//    }
//    for(int j=0; j<numberOfCities; j++)
//    {
//        for(int k=0; k<numberOfCities; k++)
//        {
//            travelPath[j][k].print();
//            cout<<" ";
//        }
//        cout<<endl;
//    }
    return 0;
}
